# wsvm-net


<!---[1] Mou, W., Tzelepis, C., Mezaris, V., Gunes, H., & Patras, I. (2017, May). ***Generic to Specific Recognition Models for Membership Analysis in Group Videos***. In Automatic Face & Gesture Recognition (FG 2017), 2017 12th IEEE International Conference on (pp. 512-517). IEEE.--->