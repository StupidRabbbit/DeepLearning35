import lasagne
from lasagne.layers import InputLayer
from libsvm import GenericSVMLayer, SpecificSVMLayer


def build_model(input_var=None, shape=None, num_classes=None, C=None, CC=None):
    """

    """
    input_layer = InputLayer(shape=shape, input_var=input_var)

    output_shape = lasagne.layers.get_output_shape(input_layer)[-1]

    svm_layer_generic = GenericSVMLayer(input_layer,
                                        num_classes=num_classes,
                                        sample_dim=output_shape,
                                        C=C,
                                        return_scores=True)

    svm_layer_specific_1 = SpecificSVMLayer(input_layer,
                                            num_classes=num_classes,
                                            sample_dim=output_shape,
                                            return_scores=True,
                                            C=C, CC=CC,
                                            generic_svm=svm_layer_generic)

    svm_layer_specific_2 = SpecificSVMLayer(input_layer,
                                            num_classes=num_classes,
                                            sample_dim=output_shape,
                                            return_scores=True,
                                            C=C, CC=CC,
                                            generic_svm=svm_layer_generic)

    svm_layer_specific_3 = SpecificSVMLayer(input_layer,
                                            num_classes=num_classes,
                                            sample_dim=output_shape,
                                            return_scores=True,
                                            C=C, CC=CC,
                                            generic_svm=svm_layer_generic)

    svm_layer_specific_4 = SpecificSVMLayer(input_layer,
                                            num_classes=num_classes,
                                            sample_dim=output_shape,
                                            return_scores=True,
                                            C=C, CC=CC,
                                            generic_svm=svm_layer_generic)

    return svm_layer_generic, \
        svm_layer_specific_1, \
        svm_layer_specific_2, \
        svm_layer_specific_3, \
        svm_layer_specific_4
