# -*- coding: utf-8 -*-
from __future__ import print_function
import argparse
import time
import sys
import os
import numpy as np
import theano
import theano.tensor as T
import lasagne
from read_data import Data
from model import build_model
import matplotlib.pyplot as plt
import pdb


def main():
    """
    ============================================================================
    Usage: python(2.7) run_exp.py <options>

    Options:
        -v, --verbose      : Set verbose mode on (default is off)
        -d, --dataset      : Select dataset (gm3, hof) [default: gm3]
        -e, --num_epochs   : Set number of epochs (default: 200)
        -b, --batch_size   : Set batch size (default: 128)
        -s, --subject_id   : Select subject id

    Description: ...

    ============================================================================
    """
    # Set up a parser for command line arguments
    parser = argparse.ArgumentParser()
    parser.add_argument("-v", "--verbose",
                        action="store_true",
                        help="increase output verbosity")
    parser.add_argument("-d", "--dataset",
                        type=str,
                        choices=['gm3', 'hof'],
                        default='gm3',
                        help="select a dataset among {'gm3', 'hof'} [default: 'gm3']")
    parser.add_argument("-e", "--num_epochs",
                        type=int,
                        default=1000,
                        help="set number of training epochs [default: 1000]")
    parser.add_argument("-b", "--batch_size",
                        type=int,
                        default=40,
                        help="set mini-batch size for training/testing [default: 40]")
    parser.add_argument("-s", "--subject_id",
                        type=int,
                        choices=[0, 1, 2, 3],
                        default=0,
                        help="select subject id [default: 0]")
    args = parser.parse_args()

    # Define basic hyper-parameters
    # learning_rate = 0.001
    lrs = {1: 0.001, 100: 0.001, 250: 0.001, 500: 0.001, 750: 0.001}
    C_svm_gen = C_svm_spec = 15

    # Prepare Theano variables
    input_var = T.fmatrix('inputs')
    index = T.iscalar('index')
    target_var = T.ivector('targets')
    spec_1 = T.ivector('is_label_1')
    spec_2 = T.ivector('is_label_2')
    spec_3 = T.ivector('is_label_3')
    spec_4 = T.ivector('is_label_4')

    # Set data shape and classes based on the selected dataset
    if args.dataset == 'gm3':
        data_shape = (args.batch_size, 209)
        num_classes = 3
        classes = theano.shared(np.asarray([0, 1, 2]).astype('int32'))
    elif args.dataset == 'hof':
        data_shape = (args.batch_size, 870)
        num_classes = 4
        classes = theano.shared(np.asarray([0, 1, 2, 3]).astype('int32'))

    # Create results dir (if it doesn't exist)
    results_dir = "./results"
    if not os.path.exists(results_dir):
        os.mkdir(results_dir)

    ###########################################################################
    ##                                                                       ##
    ##                       Build model and functions                       ##
    ##                                                                       ##
    ###########################################################################
    if args.verbose:
        print("# Build model and functions...", end="")
        sys.stdout.flush()
        build_start_time = time.time()

    # Build model (see model.py)
    svm_layer_generic, \
        svm_layer_specific_1, \
        svm_layer_specific_2, \
        svm_layer_specific_3, \
        svm_layer_specific_4 = build_model(input_var=input_var,
                                           shape=data_shape,
                                           num_classes=num_classes,
                                           C=C_svm_gen,
                                           CC=C_svm_spec)

    # Get the expressions for generic and specific scores
    scores_generic, \
        scores_specific_1, \
        scores_specific_2, \
        scores_specific_3, \
        scores_specific_4 = lasagne.layers.get_output([svm_layer_generic,
                                                       svm_layer_specific_1,
                                                       svm_layer_specific_2,
                                                       svm_layer_specific_3,
                                                       svm_layer_specific_4])

    # Define expressions for generic and specific costs
    cost_generic, cost_per_sample_generic = \
        svm_layer_generic.get_one_vs_all_cost_from_scores(scores_generic,
                                                          target=target_var)
    cost_specific_1, cost_per_sample_specific_1 = \
        svm_layer_specific_1.get_one_vs_all_cost_from_scores_specific(scores_specific_1,
                                                                      target=target_var)
    cost_specific_2, cost_per_sample_specific_2 = \
        svm_layer_specific_2.get_one_vs_all_cost_from_scores_specific(scores_specific_2,
                                                                      target=target_var)
    cost_specific_3, cost_per_sample_specific_3 = \
        svm_layer_specific_3.get_one_vs_all_cost_from_scores_specific(scores_specific_3,
                                                                      target=target_var)
    cost_specific_4, cost_per_sample_specific_4 = \
        svm_layer_specific_4.get_one_vs_all_cost_from_scores_specific(scores_specific_4,
                                                                      target=target_var)

    cost_specific_1 = T.dot(spec_1, cost_per_sample_specific_1)
    cost_specific_2 = T.dot(spec_2, cost_per_sample_specific_2)
    cost_specific_3 = T.dot(spec_3, cost_per_sample_specific_3)
    cost_specific_4 = T.dot(spec_4, cost_per_sample_specific_4)

    max_index = scores_generic.argmax(axis=1)
    max_index_1 = scores_specific_1.argmax(axis=1)
    max_index_2 = scores_specific_2.argmax(axis=1)
    max_index_3 = scores_specific_3.argmax(axis=1)
    max_index_4 = scores_specific_4.argmax(axis=1)

    prediction = classes[max_index]
    prediction1 = classes[max_index_1]
    prediction2 = classes[max_index_2]
    prediction3 = classes[max_index_3]
    prediction4 = classes[max_index_4]

    acc = T.cast(T.mean(T.eq(prediction, target_var)), 'float32')

    num_sample_spec = spec_1.sum() + spec_2.sum() + spec_3.sum() + spec_4.sum()
    num_correct_spec = T.dot(spec_1, T.eq(prediction1, target_var)) + \
        T.dot(spec_2, T.eq(prediction2, target_var)) + \
        T.dot(spec_3, T.eq(prediction3, target_var)) + \
        T.dot(spec_4, T.eq(prediction4, target_var))

    acc_spec = num_correct_spec.astype('float32') / num_sample_spec.astype('float32')

    generic_parameters = lasagne.layers.get_all_params(svm_layer_generic)
    specific_parameters_1 = lasagne.layers.get_all_params(svm_layer_specific_1)
    specific_parameters_2 = lasagne.layers.get_all_params(svm_layer_specific_2)
    specific_parameters_3 = lasagne.layers.get_all_params(svm_layer_specific_3)
    specific_parameters_4 = lasagne.layers.get_all_params(svm_layer_specific_4)

    all_parameters = list(set(generic_parameters +
                              specific_parameters_1 +
                              specific_parameters_2 +
                              specific_parameters_3 +
                              specific_parameters_4))

    learning_rate = theano.shared(lasagne.utils.floatX(lrs[1]))
    learning_updates = lasagne.updates.sgd(cost_generic +
                                           cost_specific_1 +
                                           cost_specific_2 +
                                           cost_specific_3 +
                                           cost_specific_4,
                                           all_parameters,
                                           learning_rate=learning_rate)
    # TODO: Add comment
    datasets = Data(0)

    train_set_x, train_set_y, \
        train_set_spec_1, \
        train_set_spec_2, \
        train_set_spec_3, \
        train_set_spec_4 = datasets.shared_dataset(subset='train')

    test_set_x, test_set_y, \
        test_set_spec_1, \
        test_set_spec_2, \
        test_set_spec_3, \
        test_set_spec_4 = datasets.shared_dataset(subset='test')

    tr_given = {input_var: train_set_x[index*args.batch_size:(index+1)*args.batch_size],
                target_var: train_set_y[index*args.batch_size:(index+1)*args.batch_size],
                spec_1: train_set_spec_1[index*args.batch_size:(index+1)*args.batch_size],
                spec_2: train_set_spec_2[index*args.batch_size:(index+1)*args.batch_size],
                spec_3: train_set_spec_3[index*args.batch_size:(index+1)*args.batch_size],
                spec_4: train_set_spec_4[index*args.batch_size:(index+1)*args.batch_size]}

    train_fn = theano.function(inputs=[index],
                               outputs=[cost_generic,
                                        cost_specific_1,
                                        cost_specific_2,
                                        cost_specific_3,
                                        cost_specific_4,
                                        prediction,
                                        prediction1,
                                        prediction2,
                                        prediction3,
                                        prediction4,
                                        acc, acc_spec,
                                        target_var,
                                        spec_1,
                                        spec_2,
                                        spec_3,
                                        spec_4],
                               updates=learning_updates,
                               givens=tr_given)

    ts_given = {input_var: test_set_x[index*args.batch_size:(index+1)*args.batch_size],
                target_var: test_set_y[index*args.batch_size:(index+1)*args.batch_size],
                spec_1: test_set_spec_1[index*args.batch_size:(index+1)*args.batch_size],
                spec_2: test_set_spec_2[index*args.batch_size:(index+1)*args.batch_size],
                spec_3: test_set_spec_3[index*args.batch_size:(index+1)*args.batch_size],
                spec_4: test_set_spec_4[index*args.batch_size:(index+1)*args.batch_size]}

    test_fn = theano.function(inputs=[index],
                              outputs=[cost_generic,
                                       cost_specific_1,
                                       cost_specific_2,
                                       cost_specific_3,
                                       cost_specific_4,
                                       prediction,
                                       prediction1,
                                       prediction2,
                                       prediction3,
                                       prediction4,
                                       acc, acc_spec,
                                       target_var,
                                       spec_1,
                                       spec_2,
                                       spec_3,
                                       spec_4],
                              givens=ts_given)

    # Model and functions have been built
    if args.verbose:
        print("Done! [%.3f sec]" % (time.time() - build_start_time))

    ###########################################################################
    ##                                                                       ##
    ##                             Load Dataset                              ##
    ##                                                                       ##
    ###########################################################################
    if args.verbose:
        print("# Loading data...", end="")
        sys.stdout.flush()
        load_data_start_time = time.time()

    datasets = Data(args.subject_id)

    # Load training set
    train_set_x_val, train_set_y_val, \
        train_set_spec_1_val, \
        train_set_spec_2_val, \
        train_set_spec_3_val, \
        train_set_spec_4_val = datasets.load_dataset(subset='train')

    train_set_x.set_value(train_set_x_val)
    train_set_y.set_value(train_set_y_val)
    train_set_spec_1.set_value(train_set_spec_1_val)
    train_set_spec_2.set_value(train_set_spec_2_val)
    train_set_spec_3.set_value(train_set_spec_3_val)
    train_set_spec_4.set_value(train_set_spec_4_val)

    # Load testing set
    test_set_x_val, \
        test_set_y_val, \
        test_set_spec_1_val, \
        test_set_spec_2_val, \
        test_set_spec_3_val, \
        test_set_spec_4_val = datasets.load_dataset(subset='test')

    test_set_x.set_value(test_set_x_val)
    test_set_y.set_value(test_set_y_val)
    test_set_spec_1.set_value(test_set_spec_1_val)
    test_set_spec_2.set_value(test_set_spec_2_val)
    test_set_spec_3.set_value(test_set_spec_3_val)
    test_set_spec_4.set_value(test_set_spec_4_val)

    if args.verbose:
        print("Done! [%.3f sec]" % (time.time() - load_data_start_time))

    ###########################################################################
    ##                                                                       ##
    ##                            Run Experiment                             ##
    ##                                                                       ##
    ###########################################################################
    if args.verbose:
        print("# Start experiment for subject id %d" % args.subject_id)
        exp_start_time = time.time()

    aList_specific = []
    total_acc_train_list = []
    total_acc_test_list = []
    maxID_list = []
    total_acc_train_list_oneSUB = []
    total_acc_test_list_oneSUB = []

    # Iterate over epochs
    train_total_cost = np.zeros(args.num_epochs)
    train_total_acc = np.zeros(args.num_epochs)
    for epoch in xrange(args.num_epochs):

        print("# Epoch %d/%d" % (epoch + 1, args.num_epochs))

        ###########################################################################
        ##                               Training                                ##
        ###########################################################################

        if epoch + 1 in lrs:
            learning_rate.set_value(lasagne.utils.floatX(lrs[epoch + 1]))
            if args.verbose:
                print("\t>> Set new LR for the network: %f" % learning_rate.get_value())


        total_train_samples = train_set_x.get_value().shape[0]
        num_minibatches = total_train_samples // args.batch_size

        # Perform training in mini-batch mode
        total_acc = 0
        for mb in xrange(num_minibatches):
            cost, \
                cost_spec1, \
                cost_spec2, \
                cost_spec3, \
                cost_spec4, \
                prediction_train, \
                prediction1_train, \
                prediction2_train, \
                prediction3_train, \
                prediction4_train, \
                acc_train, \
                acc_spec_train, \
                y_train, \
                spec_1_train, \
                spec_2_train, \
                spec_3_train, \
                spec_4_train = train_fn(mb)

            cost_total = cost + cost_spec1 + cost_spec2 + cost_spec3 + cost_spec4
            total_acc = (total_acc * mb * args.batch_size +
                         acc_spec_train * args.batch_size) / ((mb + 1) * args.batch_size)
        # === End of mini-batches iteration (Training) ===
        total_acc_train_list_oneSUB.append(total_acc)

        if args.verbose:
            print("# Training results")
            print("\t-- cost_total  = %.4f" % cost_total)
            print("\t-- total_acc   = %.4f" % total_acc)

        ###########################################################################
        ##                               Testing                                 ##
        ###########################################################################
        total_test_samples = test_set_x.get_value().shape[0]
        mb_size_test = total_test_samples
        num_minibatches = total_test_samples // mb_size_test
        total_acc = 0
        for mb in xrange(num_minibatches):
            cost, \
                cost_spec1, \
                cost_spec2, \
                cost_spec3, \
                cost_spec4, \
                prediction_test, \
                prediction1_test, \
                prediction2_test, \
                prediction3_test, \
                prediction4_test, \
                acc_test, \
                acc_spec_test, \
                y_test, \
                spec_1_test, \
                spec_2_test, \
                spec_3_test, \
                spec_4_test = test_fn(mb)

            total_acc = (total_acc * mb * mb_size_test +
                         acc_spec_test * mb_size_test) / ((mb + 1) * mb_size_test)
            cost_total = cost + cost_spec1 + cost_spec2 + cost_spec3 + cost_spec4

            if args.verbose:
                print("# Testing results")
                print("\t-- cost_generic  = %.4f" % cost)
                print("\t-- Total cost    = %.4f" % cost_total)
                print("\t-- cost_specific = %.4f" %
                      (cost_spec1 + cost_spec2 + cost_spec3 + cost_spec4))
                print("\t-- acc_generic   = %.4f" % acc_test)
                print("\t-- acc_spec      = %.4f" % acc_spec_test)
        # === End of mini-batches iteration (Testing) ===

        total_acc_test_list_oneSUB.append(total_acc)
        tempID = np.where(total_acc_train_list_oneSUB ==
                          np.array(total_acc_train_list_oneSUB).max())[0][0]
        maxID_list.append(tempID)
        # pdb.set_trace()
        # aList_specific.append(total_acc)
        total_acc_test_list.append(total_acc_test_list_oneSUB)
        total_acc_train_list.append(total_acc_train_list_oneSUB)
        aList_specific.append(acc_spec_test)
    # === End of epochs iteration ===

    acc_train_plot = np.array(total_acc_train_list)
    sum_acc_train = sum(acc_train_plot, 0)
    acc_test_plot = np.array(total_acc_test_list)
    sum_acc_test = sum(acc_test_plot, 0)

    if args.verbose:
        print("Experiment complete! [%.3f sec]" % (time.time() - exp_start_time))

    mean_acc_train = sum_acc_train / acc_train_plot.shape[0]
    plt.plot(mean_acc_train)
    mean_acc_test = sum_acc_test / acc_test_plot.shape[0]
    plt.plot(mean_acc_test)
    plt.show()

    ###########################################################################
    ##                                                                       ##
    ##                             Save results                              ##
    ##                                                                       ##
    ###########################################################################
    train_acc_list_results = "%s/train_acc_list_%d" % (results_dir, args.subject_id)
    test_acc_list_results = "%s/test_acc_list_%d" % (results_dir, args.subject_id)
    test_acc_results = "%s/test_acc_%d" % (results_dir, args.subject_id)
    np.save(train_acc_list_results, total_acc_train_list)
    np.save(test_acc_list_results, total_acc_test_list)
    np.save(test_acc_results, aList_specific)


if __name__ == "__main__":
    main()
