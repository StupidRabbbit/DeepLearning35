import sys
import os
sys.path.append(os.path.join(os.getcwd(), os.pardir))
import theano
import sys
import math
import cv2
import time
from sklearn import svm
import os
import gzip
import six.moves.cPickle as pickle
import numpy
import theano.tensor as T
from sklearn import mixture
import numpy as np
import os
import random
import glob
import argparse
import scipy.io
import pdb
from scipy.stats import multivariate_normal
from sklearn.externals import joblib

    
class Data(object):
    def __init__(self, epoch):
        fpaths = './data/gm3.mat'
        current_file = scipy.io.loadmat(fpaths)
        self.allData = current_file['allData']
        self.spec_1 = current_file['spec_1'].flatten()
        self.spec_2 = current_file['spec_2'].flatten()
        self.spec_3 = current_file['spec_3'].flatten()
        self.spec_4 = current_file['spec_4'].flatten()
        self.p_ID = current_file['p_ID'].flatten()
        self.no_p = np.unique(self.p_ID)
        self.epoch = epoch
        self.Label = current_file['Label'].flatten()-1
        
    def get_train(self):
        ind = np.where(self.p_ID != self.no_p[self.epoch])
        allData = self.allData[ind]
        Label = self.Label[ind]
        spec_1 = self.spec_1[ind]
        spec_2 = self.spec_2[ind]
        spec_3 = self.spec_3[ind]
        spec_4 = self.spec_4[ind]
        return allData, Label, spec_1, spec_2, spec_3, spec_4
    
    def get_test(self):
        ind = np.where(self.p_ID == self.no_p[self.epoch])
        allData = self.allData[ind]
        Label = self.Label[ind]
        spec_1 = self.spec_1[ind]
        spec_2 = self.spec_2[ind]
        spec_3 = self.spec_3[ind]
        spec_4 = self.spec_4[ind]
        return allData, Label, spec_1, spec_2, spec_3, spec_4
        
    def get_input(self):
        return self.allData
    
    def get_spec(self, num):
        return self.spec_str(num)
    
    def get_label(self):
        return self.Label

    def get_pID(self):
        return self.p_ID
        
    def get_all(self):
        return self.allData, \
               self.Label, \
               self.spec_1, \
               self.spec_2, \
               self.spec_3, \
               self.spec_4, \
               self.p_ID
        
    def load_dataset(self, subset='train'):
        """
        Function that loads the dataset into shared variables.

        The reason we store our dataset in shared variables is to allow
        Theano to copy it into the GPU memory (when code is run on GPU).
        Since copying data into the GPU is slow, copying a minibatch everytime
        is needed (the default behaviour if the data is not in a shared
        variable) would lead to a large decrease in performance.
        """
        if subset == 'train':
            allData, Label, spec_1, spec_2,spec_3,spec_4 = self.get_train()
        else:
            allData, Label, spec_1, spec_2,spec_3,spec_4 = self.get_test()

        return allData.astype('float32'), \
               Label, spec_1.astype('int32'), \
               spec_2.astype('int32'), \
               spec_3.astype('int32'), \
               spec_4.astype('int32')

    def shared_dataset(self, subset='train', borrow=True):
        """
        Function that loads the dataset into shared variables.

        The reason we store our dataset in shared variables is to allow
        Theano to copy it into the GPU memory (when code is run on GPU).
        Since copying data into the GPU is slow, copying a minibatch everytime
        is needed (the default behaviour if the data is not in a shared
        variable) would lead to a large decrease in performance.
        """
        if subset == 'train':
            allData, Label, spec_1, spec_2, spec_3, spec_4 = self.get_train()
        else:
            allData, Label, spec_1, spec_2, spec_3, spec_4 = self.get_test()

        shared_x = theano.shared(numpy.asarray(allData, dtype='float32'), borrow=borrow)
        shared_y = theano.shared(numpy.asarray(Label, dtype='int32'), borrow=borrow)
        shared_specific_1 = theano.shared(spec_1.astype('int32'), borrow=borrow)
        shared_specific_2 = theano.shared(spec_2.astype('int32'), borrow=borrow)
        shared_specific_3 = theano.shared(spec_3.astype('int32'), borrow=borrow)
        shared_specific_4 = theano.shared(spec_4.astype('int32'), borrow=borrow)
        
        return shared_x, \
               shared_y, \
               shared_specific_1, \
               shared_specific_2, \
               shared_specific_3, \
               shared_specific_4
