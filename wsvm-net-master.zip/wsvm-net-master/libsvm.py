"""
Author  : Petar Palasek
Contact : p.palasek@qmul.ac.uk
"""
import theano
import theano.tensor as T
import lasagne
from sklearn.externals import joblib


class GenericSVMLayer(lasagne.layers.Layer):
    def __init__(self,
                 incoming,
                 learned_svm_path=None,
                 coef=lasagne.init.Normal(0.1),
                 # coef_specific=lasagne.init.Normal(0.1), #newadded
                 intercept=lasagne.init.Normal(0.1),
                 C=15,
                 trainable_C=True,
                 # intercept_specific=lasagne.init.Normal(0.1),#newadded
                 return_scores=False,
                 # return_scores_specific=False,  #newadded
                 num_classes=None,
                 sample_dim=None,
                 **kwargs):

        super(GenericSVMLayer, self).__init__(incoming, **kwargs)

        if learned_svm_path is not None:
            learned_svm_object = joblib.load(learned_svm_path)
            classes = learned_svm_object.classes_.astype('int')
            self.num_classes = len(classes)
            self.classes = theano.shared(classes)
            coef = learned_svm_object.coef_.astype('float32')
            self.sample_dim = coef.shape[1]
            intercept = learned_svm_object.intercept_.astype('float32')
        else:
            assert (coef is not None)
            assert (intercept is not None)
            assert (num_classes is not None)
            assert (sample_dim is not None)
            self.num_classes = num_classes
            self.sample_dim = sample_dim

        self._coef = self.add_param(coef,
                                    (self.num_classes, self.sample_dim),
                                    name='svm_W',
                                    regularizable=False)
        self._intercept = self.add_param(intercept,
                                         (self.num_classes,),
                                         name='svm_b',
                                         regularizable=False)
        self.C = self.add_param(lasagne.init.Constant(C),
                                (),
                                name='svm_C',
                                regularizable=False,
                                trainable=trainable_C)
        self.return_scores = return_scores

    def get_output_shape_for(self, input_shape):
        if self.return_scores:
            return (input_shape[0], self.num_classes)
        else:
            return (input_shape[0],)

    def get_output_for(self, input, **kwargs):
        if self.return_scores:
            return self.get_scores(input)
        else:
            return self.classify(input)

    def get_scores(self, sample):
        scores = T.dot(sample, self._coef.T) + self._intercept
        return scores

    def classify(self, sample):
        scores = self.get_scores(sample)
        indices = scores.argmax(axis=1)
        return self.classes[indices[0]]

    def train_svm_using_sklearn(self, X, y, C=100):
        from sklearn import svm
        learned_svm_object = svm.LinearSVC(C=C, verbose=2)
        print("starting svm train")
        learned_svm_object.fit(X, y)
        print("svm train done")
        coef = learned_svm_object.coef_.astype('float32')
        intercept = learned_svm_object.intercept_.astype('float32')
        self._coef.set_value(coef)
        self._intercept.set_value(intercept)

    def get_one_vs_all_cost_from_scores(self, scores, target):
        y_i = T.extra_ops.to_one_hot(target, self.num_classes) * 2
        y_i -= 1  # the matrix will be -1 and 1
        # Cast any tensor x to a Tensor of the same shape,
        # but with a different numerical type dtype.
        num_samples = T.cast(target.shape[0], 'float32')
        lambda_coef = 1. / (num_samples * self.C)  # fixed lambda

        # cost =  T.maximum(0, 1 - y_i * scores) ** 2
        # hinge loss changed
        cost = T.maximum(0, 1 - y_i * scores)
        # print 'cost: ', cost
        final_cost_new = cost.sum(axis=1)
        final_cost_new += 0.5 * lambda_coef * T.sum(self._coef ** 2)
        return final_cost_new.mean(), final_cost_new


class SpecificSVMLayer(lasagne.layers.Layer):
    def __init__(self,
                 incoming,
                 learned_svm_path=None,
                 coef=lasagne.init.Normal(0.1),
                 intercept=lasagne.init.Normal(0.1),
                 C=15,
                 trainable_C=True,
                 CC=15,
                 trainable_CC=False,
                 return_scores=False,
                 num_classes=None,
                 sample_dim=None,
                 generic_svm=None,
                 **kwargs):

        super(SpecificSVMLayer, self).__init__(incoming, **kwargs)

        if learned_svm_path is not None:
            learned_svm_object = joblib.load(learned_svm_path)
            classes = learned_svm_object.classes_.astype('int')
            self.num_classes = len(classes)
            self.classes = theano.shared(classes)
            coef = learned_svm_object.coef_.astype('float32')
            self.sample_dim = coef.shape[1]
            intercept = learned_svm_object.intercept_.astype('float32')
        else:
            assert (coef is not None)
            assert (intercept is not None)
            assert (num_classes is not None)
            assert (sample_dim is not None)
            self.num_classes = num_classes
            self.sample_dim = sample_dim

        assert (generic_svm is not None)
        self.generic_svm = generic_svm
        self.W0 = self.generic_svm._coef
        # the regularization is already explicitly added later
        self._coef = self.add_param(coef,
                                    (self.num_classes, self.sample_dim),
                                    name='svm_w_specific',
                                    regularizable=False)
        self._intercept = self.add_param(intercept,
                                         (self.num_classes,),
                                         name='svm_b_specific',
                                         regularizable=False)
        self.C = self.add_param(lasagne.init.Constant(C),
                                (),
                                name='svm_mu',
                                regularizable=False,
                                trainable=trainable_C)  #
        self.CC = self.add_param(lasagne.init.Constant(CC),
                                 (),
                                 name='svm_nu',
                                 regularizable=False,
                                 trainable=trainable_CC)
        self.return_scores = return_scores

    def get_output_shape_for(self, input_shape):
        if self.return_scores:
            return (input_shape[0], self.num_classes)
        else:
            return (input_shape[0],)

    def get_output_for(self, input, **kwargs):
        if self.return_scores:
            return self.get_scores(input)
        else:
            return self.classify(input)

    def get_scores(self, sample):
        scores = T.dot(sample, self._coef.T) + self._intercept
        return scores

    def classify(self, sample):
        scores = self.get_scores(sample)
        indices = scores.argmax(axis=1)
        return self.classes[indices[0]]

    def train_svm_using_sklearn(self, X, y, C=100):
        from sklearn import svm
        learned_svm_object = svm.LinearSVC(C=C, verbose=2)
        learned_svm_object.fit(X, y)
        coef = learned_svm_object.coef_.astype('float32')
        intercept = learned_svm_object.intercept_.astype('float32')
        self._coef.set_value(coef)
        self._intercept.set_value(intercept)

    def get_one_vs_all_cost_from_scores_specific(self, scores, target):
        y_i = T.extra_ops.to_one_hot(target, self.num_classes) * 2
        y_i -= 1  # the matrix will be -1 and 1
        # Cast any tensor x to a Tensor of the same shape,
        # but with a different numerical type dtype.
        num_samples = T.cast(target.shape[0], 'float32')
        mu_coef = 1. / (num_samples * self.C)  # fixed lambda
        nu_coef = self.CC  # 1. / (num_samples * self.CC)
        # cost =  T.maximum(0, 1 - y_i * scores) ** 2
        # hinge loss changed
        cost = T.maximum(0, 1 - y_i * scores)
        # print 'cost: ', cost
        final_cost_new = cost.sum(axis=1)
        final_cost_new += 0.5 * mu_coef * T.sum(self._coef ** 2) + \
                          0.5 * nu_coef * T.sum((self._coef - self.W0) ** 2)
        return final_cost_new.mean(), final_cost_new
